## rotate

rotate用于对日志文件进行切分。rotate fork自[lumberjack](https://github.com/sevenNt/lumberjack)。在lumberjack对文件夹权限、日志格式、对外API等做了稍许调整。