---
name: Questions
about: Any questions when using GoAdmin
title: "[Question]"
labels: ''
assignees: ''

---

**Description** [describe your questions]

**Example code** [If you have any code info]

**Others** [screenshots or other info]
