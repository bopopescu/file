package logger

import "testing"

func TestInfo(t *testing.T) {
	Info("test")
}
