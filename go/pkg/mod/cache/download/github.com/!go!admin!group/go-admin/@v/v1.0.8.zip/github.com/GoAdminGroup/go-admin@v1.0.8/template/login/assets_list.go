package login

var AssetsList = []string{
	"/login/dist/all.min.css",
	"/login/dist/all.min.js",
	"/login/dist/respond.min.js",
}
