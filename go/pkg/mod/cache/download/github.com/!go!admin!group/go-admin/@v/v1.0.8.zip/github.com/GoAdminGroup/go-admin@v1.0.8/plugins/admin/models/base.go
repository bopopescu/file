package models

// Base is base model structure.
type Base struct {
	Table string
}
