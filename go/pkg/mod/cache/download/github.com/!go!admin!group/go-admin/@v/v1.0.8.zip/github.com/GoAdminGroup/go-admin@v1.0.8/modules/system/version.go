package system

// Version is the version of framework.
const Version = "v1.0.8"
