# Goreman

Clone of foreman written in golang.

https://github.com/ddollar/foreman

## Getting Started

    go get github.com/mattn/goreman

## Usage

    goreman start

Will start all commands defined in the `Procfile` and display their outputs.
Any signals are forwarded to the processes.

## Example

See `_example` directory

## License

MIT

## Authors

Yasuhiro Matsumoto (a.k.a mattn)
