package circuitbreaker

import (
	"github.com/alibaba/sentinel-golang/core/base"
)

// MetricStatSlot records metrics for circuit breaker on invocation completed.
type MetricStatSlot struct {
}

func (c *MetricStatSlot) OnEntryPassed(_ *base.EntryContext) {
	// Do nothing
	return
}

func (c *MetricStatSlot) OnEntryBlocked(_ *base.EntryContext, _ *base.BlockError) {
	// Do nothing
	return
}

func (c *MetricStatSlot) OnCompleted(ctx *base.EntryContext) {
	// The slot will ignore blocked requests.
	if ctx.RuleCheckResult == nil || ctx.RuleCheckResult.IsBlocked() {
		return
	}
	res := ctx.Resource.Name()
	err := ctx.Err()
	rt := ctx.Rt()
	for _, cb := range getResBreakers(res) {
		cb.OnRequestComplete(rt, err)
	}
}
