# Apache Thrift

This is a partial copy of Apache Thrift v0.10 (https://github.com/apache/thrift/commit/b2a4d4ae21c789b689dd162deb819665567f481c).

It is vendored code to avoid compatibility issues introduced in Thrift  v0.11.

See https://github.com/jaegertracing/jaeger-client-go/pull/303.
