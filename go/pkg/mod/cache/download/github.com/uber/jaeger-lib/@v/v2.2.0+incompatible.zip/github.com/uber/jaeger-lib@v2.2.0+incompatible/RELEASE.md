# Releasing new version

  - Create a PR with title like "Preparing release 2.1.0"
    - Add recent changes to the `CHANGELOG.md`, e.g. from `git log --pretty=format:'- %s -- %an'`
  - Once the PR is merged, create a release on GitHub, e.g. v2.1.0
  - Celebrate
