package models

//go:generate stringer -type=FieldType
