package xorm

type NullType interface {
	IsNil() bool
}
